/**
 * Processing data using Doubly Linked List CST8130 Data Structures,
 * Computer Engineering Technology-Computer Science: Level 3
 * 
 * Professor: James Mwangi PhD
 * 
 * 
 * Student Name:____QianJun_____ _____Liu______
 * Student ID:__041150452__
 * Program: Computer Science Technology
 * Course: CST8130 - Data Structures
 * Lab Section:	assignment3
 * 
 */
package dataStructure_Assignments3_package1;

import java.io.BufferedReader;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Map;

import dataStructure_Assignments3_package2.PostalCodeEntry;

/**
 * This class demonstrates the functionality of the PostalCodeHashMap by reading
 * postal code data from a CSV file and performing search operations.
 *
 * @author James, Georger
 */
public class PostalCodeSearchTest {

	/**
	 * The main method which opens and reads a CSV file of Canadian postal codes,
	 * populates a PostalCodeHashMap, and then performs random searches.
	 *
	 * @param args command line arguments (not used in this application).
	 * @throws IOException if an error occurs while opening or reading the CSV file.
	 */
	public static void main(String[] args) {
		PostalCodeHashMap postalCodeHashMap = new PostalCodeHashMap();

		String filename = "OttawaPostalCodes.csv";
		Path file = Paths.get(filename);
		try (BufferedReader input = Files.newBufferedReader(file)) {
			String line = null;
			while ((line = input.readLine()) != null) {
				//System.out.println(line);
				String[] parts = line.trim().split(","); 
				if (parts.length >= 2) {
				//System.out.println("parts: " + parts[0] + ", " + parts[1]+ ", " + parts[2]+ ", " + parts[3]+ ", " + parts[4]);
				PostalCodeEntry postalCodeEntry = new PostalCodeEntry(parts[0], parts[1],parts[2],parts[3],parts[4]);
				postalCodeHashMap.addPostalCode(postalCodeEntry);
				//TestSetMap.treeMapDriver.put(Integer.parseInt(parts[1]), parts[0]);
				}
			}//while
		}
		catch (IOException ioException) {
			System.err.println("Error opening file");
			ioException.printStackTrace();

		} 
		
//        for (Map.Entry<String, PostalCodeEntry> entry : postalCodeHashMap.entrySet()) {
//            System.out.println(entry.getKey() + ": " + entry.getValue());
//        	}
        
        for(int i=0;i<9;i++) {
        	String radomString=PostalCodeEntry.getRandomPrefix();
        	System.out.println("Retrieving: "+radomString);
        	if (postalCodeHashMap.containPostalCode(radomString)) {
                System.out.println(postalCodeHashMap.getPostalCode(radomString));
            } else {
                System.out.println("No found.");
            }
        }
		// no need to close input. Used try-with-resources above
	}// main()

}// class
