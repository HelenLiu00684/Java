/**
 * Processing data using Doubly Linked List CST8130 Data Structures,
 * Computer Engineering Technology-Computer Science: Level 3
 * 
 * Professor: James Mwangi PhD
 * 
 * 
 * Student Name:____QianJun_____ _____Liu______
 * Student ID:__041150452__
 * Program: Computer Science Technology
 * Course: CST8130 - Data Structures
 * Lab Section:	assignment3
 * 
 */
package dataStructure_Assignments3_package1;

import java.util.HashMap;
import java.util.Map;
import dataStructure_Assignments3_package2.PostalCodeEntry;

import java.util.Set;

/**
 * Represents a collection of postal code entries, using a HashMap for storage.
 * Provides methods to add, retrieve, remove, check for, and manage postal code entries.
 *
 * @author James, Georger
 */
public class PostalCodeHashMap {
	private Map<String, PostalCodeEntry> postalCodeHashMap;

    /**
     * Constructs an empty PostalCodeHashMap.
     * Initializes the underlying HashMap.
     */
	public PostalCodeHashMap() {
		this.postalCodeHashMap = new HashMap<>();
	}
    /**
     * Adds a PostalCodeEntry to the HashMap.
     * The postal code's prefix is used as the key.
     *
     * @param postalcode The PostalCodeEntry to be added.
     */
	public void addPostalCode(PostalCodeEntry postalcode) {
		this.postalCodeHashMap.put(postalcode.getPrefix(),postalcode);
	}
    /**
     * Retrieves a PostalCodeEntry from the HashMap based on its prefix.
     *
     * @param postalcodeprefix The prefix of the postal code to retrieve.
     * @return The PostalCodeEntry associated with the given prefix, or null if not found.
     */
	public PostalCodeEntry getPostalCode(String postalcodeprefix) {
		return this.postalCodeHashMap.get(postalcodeprefix);
	};
    /**
     * Removes a PostalCodeEntry from the HashMap based on its prefix.
     *
     * @param postalcodeprefix The prefix of the postal code to remove.
     */
	public void removePostalCode(String postalcodeprefix) {
		this.postalCodeHashMap.remove(postalcodeprefix);
	};
    /**
     * Checks if the HashMap contains a PostalCodeEntry with the given prefix.
     *
     * @param postalcodeprefix The prefix of the postal code to check for.
     * @return True if a PostalCodeEntry with the given prefix exists in the map, false otherwise.
     */
	public boolean containPostalCode(String postalcodeprefix) {
		return this.postalCodeHashMap.containsKey(postalcodeprefix);
	};
    /**
     * Returns the number of PostalCodeEntry objects currently stored in the HashMap.
     *
     * @return The size of the HashMap.
     */
	public int size() {
		return this.postalCodeHashMap.size();
	};
	
    /**
     * Returns the underlying HashMap containing postal code entries.
     *
     * @return The Map where keys are postal code prefixes and values are PostalCodeEntry objects.
     */
	public Map<String, PostalCodeEntry> getPostalCodeHashMap() {
		return postalCodeHashMap;
	}
    /**
     * Returns a Set view of the entries contained in this HashMap.
     * Each element in the returned set is a Map.Entry object.
     *
     * @return A Set of Map.Entry objects representing the key-value pairs in the HashMap.
     */
    public Set<Map.Entry<String, PostalCodeEntry>> entrySet() {
        return postalCodeHashMap.entrySet(); 
    }
    /**
     * Sets the underlying HashMap to the provided Map.
     *
     * @param postalCodeHashMap The new HashMap to be used for storing postal code entries.
     */
	public void setPostalCodeHashMap(Map<String, PostalCodeEntry> postalCodeHashMap) {
		this.postalCodeHashMap = postalCodeHashMap;
	}
	

}
