package Amazonsystem;

import java.time.LocalDate;

public class AmazonCash extends AmazonCredit{
	

	private AmazonCash(float amountcash) {
		super(amountcash,PaymentType.Cash);
	}
	
	public static AmazonCash createCash(String[] str) {
		// TODO Auto-generated method stub
		AmazonCash amazoncash;
		float amountcash;
		if ((str==null)||(str.length)!=1)
			return null;
		for (String s:str) {
			if (s.isBlank()||s.isEmpty())
				return null;
			}
		//input format :str = "'9999.01'"
		try {
			amountcash = Float.parseFloat(str[0]);
	        return amazoncash = new AmazonCash(amountcash);  
		}catch (NumberFormatException e) {  
	        return null;  
	    }	

	}
		
}

