package Amazonsystem;

public class AmazonProductException {

}
