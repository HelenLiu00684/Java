package Amazonsystem;

import java.io.BufferedReader;  
import java.io.FileReader;  
import java.io.IOException;

public class AmazonProductUtil {
	public static final int NUMCOLS=10;
	public static float convertStrToFloat(String str) {

		 return Float.parseFloat(str);
	};


//	
//	public String[] lineReader(String line) {
//		/*
//		-START String[] printCSVLine(String line)
//		    -Create a local array of strings
//		    -Start defining index to 0
//		    -Set start to 0
//		    -Set end to the first location of a comma (,)
//		    -While start < line.length
//		        -If character at start position is quotes (™)
//		            -Set start to start + 1
//		            -Set end to the first location of quotes (") after start
//		        -Set value to the substring between start and end
//		        -Remove leading and trailing spaces from value
//		        -Include value in the string list and update the index
//		        -If character at end position is quotes (™)
//		            -Set start to end + 2
//		        -else
//		            -Set start to end + 1
//		        -Set end to the first location of quotes after start
//		    -If start is less then end of line
//		         -Update value to be a final substring from start until the end
//		         -Include value in the string list and update the index
//		-Return the array of strings
//		*/
//		String[] str = new String[NUMCOLS];
//		int index = 0;
//		final char chComma = ',';
//		final char chQuotes = '"';
//		int start = 0;
//		int end = line.indexOf(chComma);
//		String value;
//		while (start<end) {
//			if (line.charAt(start)==chQuotes) {
//				start++;
//				end = line.indexOf(chQuotes, start+1); 
//			}
//			value = line.substring(start, end);
//			value = value.trim();
//			if (index >= 6) {
//				str[index++] = extractNumerics(value);
//			}else {
//				str[index++] = value;
//			}
//
//			if (line.charAt(end)==chQuotes)
//				start = end+2;
//			else
//				start = end+1;
//			end = line.indexOf(chComma, start+1);
//		}
//		if (start < line.length()) {
//			value = line.substring(start);
//			str[index++] = value;	
//		}
//		return str;
//	}
	
	// Method for parsing lines
	public String[] lineReader(String line) {
		String[] CSVArray = new String[10];
		int index = 0;
		int start = 0;
		int end;
		String value;
		
		line = line.trim();
		end = line.indexOf(",", start);
		
		//System.out.println("Total characters in the string: " + line.length());
		
		while (start < line.length() && end != -1) {
			
			while (line.charAt(start) == ' ') {
				start = start + 1;
				}
			if (line.charAt(start) == '"') {
				start = start + 1;
				//System.out.println("Start equals " + start);
				end = line.indexOf("\"", start);}
			else end = line.indexOf(",", start);
			
			//System.out.println("Start equals " + start + " Start Char: " + line.charAt(start));
			//System.out.println("End equals " + end + " End Char: " + line.charAt(end));

			value = line.substring(start, end);
			value = value.trim();		// gets rid of spaces

			
			if (index >= 6) {
				CSVArray[index++] = extractNumerics(value);
			}else {
				CSVArray[index++] = value;
			}

			
			//System.out.println(end);
			if (line.charAt(end) == '"') { 
				start = end + 2;
				}
			else {
				start = end + 1; 
				}
			end = line.indexOf(",", start);
		}

		if (start < line.length() - 1) {
			value = line.substring(start, line.length());
			value = value.trim();		// gets rid of spaces
			//System.out.println(value);
			CSVArray[index] = value;
			}
			 
			 return CSVArray;
	}


	
	public static String extractNumerics(String inputString) {

        StringBuffer sb = new StringBuffer(inputString);
        StringBuffer result = new StringBuffer();

        	
        for(int i=0; i < sb.length(); i++){  
        	 int specificI = sb.codePointAt(i);

         	if (specificI == 48 || specificI == 49 || specificI == 50 
        			|| specificI == 51 || specificI == 52 || specificI == 53 || specificI == 54 
        			|| specificI == 55 || specificI == 56 || specificI == 57 
        			|| specificI == 46) 
        				{ 
        				//System.out.println("In Loop with " + specificI);
        				result.append(sb.charAt(i));
        				}
        	}       
        return result.toString();  
    }
}
	


