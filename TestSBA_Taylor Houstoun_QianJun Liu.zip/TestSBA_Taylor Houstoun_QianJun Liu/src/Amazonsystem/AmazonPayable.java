package Amazonsystem;

public interface AmazonPayable {
    boolean pay(float payResult);
}
