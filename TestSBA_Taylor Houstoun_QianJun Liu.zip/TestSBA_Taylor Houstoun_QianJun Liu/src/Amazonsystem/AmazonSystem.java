package Amazonsystem;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.List;

public class AmazonSystem {

static List<AmazonCustomer> customers = new ArrayList<AmazonCustomer>();

public AmazonSystem () {
	String[] s = {"1", "Taylor", "1 First St, Ottawa"}; //
	AmazonCustomer customer = AmazonCustomer.createAmazonCustomer(s);
	customers.add (customer);
}
	
	public void save(String filename) {
		try {		
			FileOutputStream output = new FileOutputStream(filename);
			ObjectOutputStream oostream = new ObjectOutputStream(output);
			oostream.writeObject(customers);
		} catch (IOException e) {
			System.out.println(e);	
		}
	}
	
	public void load(String filename) {
		try {
			FileInputStream input = new FileInputStream(filename);
			ObjectInputStream oistream = new ObjectInputStream(input);
			customers = (List<AmazonCustomer>) oistream.readObject();
		} catch (IOException | ClassNotFoundException e) {
			System.out.println(e);
			}
	
	}
	
	public void show(List<AmazonCustomer> customers) {
		System.out.println("\033[1;96mSHOWING AMAZON DATA ::::::::::::::::::::::::::::::::::::\033[0m");
		System.out.println("\033[3;96mExam by: Qianjun Liu and Taylor Houstoun\033[0m");
		for (AmazonCustomer e: customers) {
			System.out.println("\033[92m" + e.toString() + "\033[0m" );
			System.out.println(" - Credit list:");

			for(AmazonCredit credit: e.getAmazonCredits()) {
				System.out.println(credit.toString());
			}
			System.out.print(" - Wish list:");
			int id=0;
			if(e.getProductwishlist().size()==0) {
				System.out.println("[No wish list]");
			}else {
				for(AmazonProduct product: e.getProductwishlist()) {
					System.out.print("  - Wishlist ["+id++);
					System.out.println(product.WishlistoString());
				}
			}
			System.out.print(" - Cart:");
			id=0;
			if(e.amazonCart.getamazonCartItems().size()==0) {
				System.out.println("[No items]");
			}else {
				for(AmazonCartItem cartItem: e.amazonCart.getamazonCartItems()) {
					System.out.print(" \n - Item["+id++);
					System.out.println(cartItem.cartItemtoString());
				}
			}
			System.out.print(" - Comments:");
			id=0;
			//if(e.amazonCart.getamazonCartItems().size()==0) {
			if(e.amazonCommentList.size()==0) {
				System.out.println("[No comments]");
			}else {
				System.out.print("\n");
				for(AmazonComment comment: e.getAmazonCommentList()) {
					System.out.print("  - Comment["+id+++"]:ProdId: ");
					System.out.println(comment.toString());
				}
			}

		}
		

	}
	
	
	
	
	
	
//	public static void main(String[] args) throws IOException {
//		AmazonSystem as = new AmazonSystem();
//			as.load("C:\\CST8132\\Taylor.txt");
//			as.show(customers);
//			
//		} 
//		
//
//		

	
}

