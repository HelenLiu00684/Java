package Amazonsystem;



public abstract class AmazonCredit {
	private float amount;

	private PaymentType type;

	public enum PaymentType {
		
		Cash,Check,Card
	}

	private int id=0;
	
	protected AmazonCredit(float amount, PaymentType type) {
		this.amount = amount;
		this.type =  type;
		this.id++;
		}

	public void Payment(float amount) {
		setAmount(amount);
	}
	
	public void setAmount(float amount) {
		this.amount = amount;
	}

	
	public float getAmount() {
		return amount;
	}


	public PaymentType getType() {
		return type;
	}

	public void setType(PaymentType type) {
		this.type = type;
	} 
	

	@Override
	public String toString() {
		//- Credit [0]:Type: Cash, value: 55.6].
		//return "- Credit ["  + ", type=" + type + "]";
		return "    - Credit [" +id+"]" + ": Type=" + type + ",value: "+getAmount()+"]";
	} 
	
	
	
}
