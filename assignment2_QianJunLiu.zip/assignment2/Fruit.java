package assignment2;

/**
 * CET - CS Academic Level 3 This class contains Assignment 1 Student Name:
 * QianJun Liu Student Number: 041150452 Course: CST8130 - Data Structures
 * 
 * @author/Professor: James Mwangi PhD.
 * 
 */
import java.io.IOException;
import java.io.Serializable;
import java.util.Arrays;
import java.util.Formatter;
import java.util.Scanner;

/**
 * CET - CS Academic Level 3 This class contains Assignment 1 Student Name:
 * QianJun Liu Student Number: 041150452 Course: CST8130 - Data Structures
 * 
 * @author/Professor: James Mwangi PhD.
 * 
 */

public class Fruit extends FoodItem implements Serializable {
	protected String orchardName = "NONONO";

	protected boolean addItem(Scanner keyboard, boolean fromFile) {
		keyboard.useDelimiter("\n"); // set seperation symbol

		if (super.addItem(keyboard, fromFile)) {
			if (!fromFile) {
				System.out.print("Enter the name of the orchard supplier:");
				// keyboard.nextLine();
				this.orchardName = keyboard.nextLine();
				return true;
			} else {
				this.orchardName = keyboard.next();
				return true;
			}


		}
		return false;

	}
	@Override
	public void outputItem(Formatter writer) throws IOException {
		super.outputItem(writer);
		writer.format("%s%n", this.orchardName);
	}
	protected Fruit() {
		super();
	}

	@Override
	public String toString() {
		return super.toString() + " orchard name:" + orchardName;
	};


}
