package assignment2;

/**
 * CET - CS Academic Level 3 This class contains Assignment 1 Student Name:
 * QianJun Liu Student Number: 041150452 Course: CST8130 - Data Structures
 * 
 * @author/Professor: James Mwangi PhD.
 * 
 */
import java.io.IOException;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Formatter;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.Scanner;



public abstract class FoodItem implements Serializable {

	protected int itemCode; // Variable to save the scanner input.....
	protected String itemName;
	protected float itemPrice;
	protected int itemQuantityinStock;
	protected float itemCost;
//	private boolean flag = true;

	protected FoodItem() {
	};

	boolean updateitem(int amount) {
		itemQuantityinStock = itemQuantityinStock + amount;
		return true;
	};

	protected boolean isEqual(FoodItem foodItem) {
		if (foodItem.getItemCode() == this.itemCode) {
			return true;
		}
		return false;
	};


	protected boolean addItem(Scanner keyboard, boolean fromFile) {
		keyboard.useDelimiter("\n"); // set seperation symbol
		boolean flag = true;
		if (fromFile) {
			if (inputCode(keyboard, true)) {
				if (keyboard.hasNext()) {
					this.itemName = keyboard.next();
					this.itemQuantityinStock = Integer.parseInt(keyboard.next());
					this.itemCost = Float.parseFloat(keyboard.next());
					this.itemPrice = Float.parseFloat(keyboard.next());

				}
			} else {
				flag = false; // Set flag to false if inputCode fails
			}
		}

		if (!fromFile) {
			//System.out.println("mannual:" + inputCode(keyboard, false));
			if (inputCode(keyboard, false)) { // Simplified condition
				while (true) { // Loop for itemName input
					this.itemName = Utilityhelper.helpreadString("Enter the name for the item:", String.class);
					if (this.itemName != null)
						break; // Exit loop if input is valid
				}

				while (true) { // Loop for itemQuantityinStock input
					this.itemQuantityinStock = Utilityhelper.helpreadInt("Enter the quantity for the item:",
							Integer.class);
					if (this.itemQuantityinStock != -1)
						break;
				}

				while (true) { // Loop for itemCost input
					this.itemCost = Utilityhelper.helpreadFloat("Enter the cost of the item:", Float.class);
					if (this.itemCost != -1)
						break;
				}

				while (true) { // Loop for itemPrice input
					this.itemPrice = Utilityhelper.helpreadFloat("Enter the sales price of the item:", Float.class);
					if (this.itemPrice != -1)
						break;
				}
			} else {
				flag = false; // Set flag to false if inputCode fails
			}
		}


		return flag;
	}

	@SuppressWarnings("unlikely-arg-type")
	public boolean inputCode(Scanner keyboard, boolean fromFile) {

		int icode = -1;

		boolean result = true; // result - 'true' valid codeNumber; result - 'false' invalid quit the program;

		while (true) {
			if (!fromFile) {
				this.itemCode = Utilityhelper.helpreadInt("Enter the code for the item:", Integer.class);
			} else {
				this.itemCode = Integer.parseInt(keyboard.next());
				icode = this.itemCode;
			}

			if (this.itemCode != -1)
				break;
		}

		try {
			for (FoodItem fd : Inventory.arrayFoods) {

				if (fd.getItemCode() == icode) {
					// System.out.println(icode+"is duplicated...Return to main menu:" );
					result = false;
				}
			}
		} catch (NullPointerException e) {
			// System.out.println("FoodItems are empty or don't have duplicated
			// number......");
			result = true;
		}
		// System.out.printf("The inputcode result is: "+result);
		return result;

	}
	public void outputItem(Formatter writer) throws IOException {
	
        writer.format("%d%n", itemCode);
        writer.format("%s%n", itemName);
        writer.format("%d%n", itemQuantityinStock);
        writer.format("%.2f%n", itemCost);
        writer.format("%.2f%n", itemPrice);
    }
	public int getItemCode() {
		return itemCode;
	}

	@Override
	public String toString() {
		return "Item:" + itemCode + " " + itemName + " " + itemQuantityinStock + " price:" + "$" + itemPrice + " cost:"
				+ "$" + itemCost;
	};




}
