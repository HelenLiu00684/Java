package assignment2;
/**
 * CET - CS Academic Level 3 This class contains Assignment 1 Student Name:
 * QianJun Liu Student Number: 041150452 Course: CST8130 - Data Structures
 * 
 * @author/Professor: James Mwangi PhD.
 * 
 */
import java.io.IOException;
import java.io.Serializable;
import java.util.Formatter;
import java.util.Scanner;



public class Vegetable extends FoodItem implements Serializable {
	private String farmName;

	protected boolean addItem(Scanner keyboard, boolean fromFile) {
		keyboard.useDelimiter("\n"); 
		if (super.addItem(keyboard, fromFile)) {

			if (!fromFile) {
				while (true) {
					this.farmName = Utilityhelper.helpreadString("Enter the name of the farm supplier:", String.class);
					if (this.farmName != null)
						break;
				}
			} else {
				this.farmName = keyboard.next();
			}

		}
		return true;

	}

	protected Vegetable() {
		super();
	}

	@Override
	public String toString() {
		return super.toString() + " farm supplier:" + farmName;
	};
	@Override	
	public void outputItem(Formatter writer) throws IOException {
		super.outputItem(writer);
		writer.format("%s%n", this.farmName);
	}
}
