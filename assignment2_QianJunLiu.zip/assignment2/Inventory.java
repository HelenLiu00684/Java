package assignment2;
/**
 * CET - CS Academic Level 3 This class contains Assignment 1 Student Name:
 * QianJun Liu Student Number: 041150452 Course: CST8130 - Data Structures
 * 
 * @author/Professor: James Mwangi PhD.
 * 
 */
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.Formatter;
import java.util.InputMismatchException;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;
import java.util.regex.Pattern;

/**
 * Inventory class which runs methods on food items and instantiates an array of
 * food items which is operated on.
 * 
 * @param inventory A collection arrayList of FoodItems.
 * 
 *                  
 */

public class Inventory {


	protected static ArrayList<FoodItem> arrayFoods = new ArrayList<>();

	protected static List<String> lines = new ArrayList<>();

	//protected static Iterator<String> iterator;


	protected FoodItem item;



	public Inventory() {
	};

	protected boolean addItem(Scanner keyboard, boolean fromFile) {
		boolean itemAddedBoolean;// To check a new object has been created
		int itemAlreadyCheck=-1;// To ehceck this new object has been created before.return n:finding existing
								// item, return -1:not finding existing item.
		boolean flag = false; // to record the result of this add action is success (true)or
								// not(false)........
		char lowerCaseCharVal;
		char linesCharVal = 0;
		
		if (!fromFile) {
			keyboard = Assign2.keyboard;
			item=null;
			while (!flag) {

				System.out.print("Do you wish to add a fruit(f),vegetable(v),preserve(p),or a seafood(s)?");
				try {
					Pattern pattern = Pattern.compile("[f,v,p,s,F,V,P,S]");
					lowerCaseCharVal = Character.toLowerCase(keyboard.next().charAt(0));

					keyboard.nextLine();

					if (pattern.matcher(String.valueOf(lowerCaseCharVal)).matches()
							|| pattern.matcher(String.valueOf(linesCharVal)).matches())

						switch (lowerCaseCharVal) {
						case 'f':
							item = new Fruit();
							break;
						case 'v':
							item = new Vegetable();
							break;
						case 'p':
							item = new Preserve();
							break;
						case 's':
							item = new Seafood();
							break;
						default: // 
							flag = true; // 
							break;
						}

					if (item != null) { // 
						// itemAddedBoolean = item.addItem(keyboard);
						itemAddedBoolean = item.addItem(keyboard, false);

						itemAlreadyCheck = alreadyExists(item);
						if (itemAlreadyCheck == -1 && itemAddedBoolean) {
						//if (itemAlreadyCheck != -1 && itemAddedBoolean) {
							System.out.println("The Item index " + itemAlreadyCheck
									+ " is not existing..... Item will  be created. ");
							arrayFoods.add(item);
							flag = true;
						} 

					}
				} catch (InputMismatchException e) { // This catches the mismatchFormatted that occurs when you don't
														// input
														// a
														// char.
					System.err.println("Error: You did not input an valid value to reprsent food. Try again.\n"); //
					keyboard.next();
				}
			}
		} else {
			item=null;
			while (keyboard.hasNext()) {
				// System.out.println(keyboard.next());
				lowerCaseCharVal = keyboard.next().charAt(0);
				//System.out.println("lowerCaseCharVal: " + lowerCaseCharVal);
				switch (lowerCaseCharVal) {
				case 'f':
					item = new Fruit();
					break;
				case 'v':
					item = new Vegetable();
					break;
				case 'p':
					item = new Preserve();
					break;
				case 's':
					item = new Seafood();
					break;
				default: // 
					flag = true; // 
					break;
				}

				if (item != null && keyboard.hasNext()) { // 
					// itemAddedBoolean = item.addItem(keyboard);
					itemAddedBoolean = item.addItem(keyboard, true);
					itemAlreadyCheck = alreadyExists(item);
					if (itemAlreadyCheck == -1 && itemAddedBoolean) {
						System.out.println(
								"The Item index " + itemAlreadyCheck + " is not existing..... Item will be created. ");
						arrayFoods.add(item);
						flag = true;
					} 


				}
			}
		}
		// Using Comparator to order arrayFoods based on ItemCode
		Collections.sort(arrayFoods, new Comparator<FoodItem>() {
			@Override
			public int compare(FoodItem item1, FoodItem item2) {
				return item1.getItemCode() - item2.getItemCode();
			}
		});
		return flag;// This return is not working in Sample demo!!!!!!
	};

	private int alreadyExists(FoodItem fooditemNew) {// return n:finding existing item, return -1:not finding existing
		FoodItem fd=null;											// item.
		// int itemCode=fooditem.getItemCode();
		fd = fooditemNew;
		try {
			for (FoodItem foodItem : arrayFoods) {
				if (foodItem.getItemCode() == fd.getItemCode()) {
					return foodItem.getItemCode();
				}
				
			}
			return -1;
		} catch (NullPointerException e) {
			return -1;
		}

	}

	@SuppressWarnings("null")
	protected boolean updateQuantity(Scanner keyboard, boolean bsflag) {// This function is integration add or reduce
																		// method together.
		boolean flag = false; // to check input value is an valid number....
		boolean result = true; // Return result of update is working or not....
		int inputcode = -1; // save the input item code....
		int inputQuantity = -1; // save the input item quantity....

		if (arrayFoods == null) {
			// System.err.println("FoodItemCodeslist need initialize......");
			return false;
		}
		boolean hasElements = false;

		for (FoodItem item : arrayFoods) {
			if (item != null) {
				hasElements = true;
				break;
			}
		}

		if (!hasElements) {
			return false;
		}
		while (!flag) { // Create a number.
			System.out.print("Enter the code for the item:"); // covert helperCheck integer......
			if (keyboard.hasNextInt()) {
				try {
					inputcode = Integer.parseInt(keyboard.next());
					flag = true; // quit the input while
				} catch (NumberFormatException e) {
					System.err.println("Error: Invalid input. Please enter an integer.");
				}
			} else {
				System.out.println("Error: Invalid input. Please enter an integer.");
				keyboard.next(); // clear input buffer
			}
		}

		flag = false;
		while (!flag) {
			System.out.print("Enter the valid quantity to buy (positive integer): "); // covert helperCheck
																						// integer......
			if (keyboard.hasNextInt()) {
				inputQuantity = keyboard.nextInt();
				if (inputQuantity >= 0) {// the inputQuantity is position integer
					flag = true;// quit the input while
				} else {
					System.out.println("Error: Quantity must be non-negative integer.");
				}
			} else {
				System.out.println("Error: Invalid input. Please enter an integer.");
				keyboard.next(); // clear input buffer
			}
		}

		item = null;
		for (FoodItem fd : arrayFoods) { // To recode the valid item code and quantity
			if (fd != null && fd.getItemCode() == inputcode) {
				item = fd;
			}
		}

		if (alreadyExists(item) == -1) { // Find duplicated item in a arrayList

			return false;
		}

		if (bsflag == true) {
			item.updateitem(inputQuantity); // This function is add the input quantity to the existing quantity amounts

		} else if (bsflag == false) { // This function is reducethe input quantity to the existing quantity amounts
			if (item.itemQuantityinStock >= inputQuantity) {
				item.updateitem(0 - inputQuantity);
			} else {
				System.out.println("Insufficient stock in inventory...... " + item.itemQuantityinStock);
				return false; // if the amount is insufficient, reduction is begin roll back and produce a
								// warning.
			}
		}
		return result;
	}

	protected void displayInventory() { // display all items of arraylist.....
		// TODO Auto-generated method stub
		// before Sorting arraylist: iterate using Iterator
		System.out.println("Inventory");
		Iterator<FoodItem> fdIterator = arrayFoods.iterator();

		try {
			while (fdIterator.hasNext()) {

				System.out.println(fdIterator.next());
			}
		} catch (NullPointerException e) {

			System.out.println("arrayFoods is empty!");
		}

	}

	public boolean searchForItem(Scanner keyboard) {
		int intVal=0;
		int positionrecBS=-1;
		System.out.println("Enter the code for the item:");
		intVal = Integer.parseInt(keyboard.nextLine());
		System.out.println("This is the delivery arrayFoods"+intVal);
		for(FoodItem fd:arrayFoods) {
			System.out.println(fd.toString());
			}

		positionrecBS = Utilityhelper.helpRecursiveBinarySearch(intVal, arrayFoods, 0, arrayFoods.size() - 1);

		if (positionrecBS == -1) {
			System.out.println(intVal + " was not found: iterativeBinarySearch");
			return false;
		} else {
			System.out.println(intVal + " was found at index position by recursiveBinarySearch.");
			System.out.println(arrayFoods.get(positionrecBS));
			return true;
		}
	};

	public void saveToFile(Scanner keyboard) {
        System.out.println("Please input the file name:");
        String fileName = keyboard.nextLine();

        try (FileWriter writer = new FileWriter(fileName); 
             Formatter formatter = new Formatter(writer)) { 

            for (FoodItem fd : arrayFoods) {
            	if (fd instanceof Fruit) {
            		formatter.format("f%n");
            		fd.outputItem(formatter); // invoke  Fruit  outputItem 
                } else if (fd instanceof Vegetable) {
                	formatter.format("v%n");
                	fd.outputItem(formatter); 
                } else if (fd instanceof Preserve) {
                	formatter.format("p%n");
                	fd.outputItem(formatter); 
                } else if (fd instanceof Seafood) {
                	formatter.format("s%n");
                	fd.outputItem(formatter); 
                }
            }



        } catch (IOException e) {
            System.err.println("saving error" + e.getMessage()); //save error
        }
		//return false;
	};

	public void readFromFile(Scanner keyboard) {

	    System.out.println("Please input the file name:");
	    String fileName = keyboard.nextLine();

	    try (BufferedReader reader = new BufferedReader(new FileReader(fileName))) { // open file
	        String line;
	        while ((line = reader.readLine()) != null) {
	            lines.add(line);
	        }
	    } catch (FileNotFoundException e) {
	        System.out.println("file not exist " + fileName); 

	        return; 

	    } catch (IOException e) {
	        e.printStackTrace();
	    }


	    String content = String.join("\n", lines);
	    keyboard = new Scanner(content);
	    addItem(keyboard, true);
	}
	

}
