package assignment2;
/**
 * CET - CS Academic Level 3 This class contains Assignment 1 Student Name:
 * QianJun Liu Student Number: 041150452 Course: CST8130 - Data Structures
 * 
 * @author/Professor: James Mwangi PhD.
 * 
 */
import java.io.IOException;
import java.util.Formatter;
import java.util.Scanner;



public class Seafood extends FoodItem {
	private String SeafoodSupplierName;

	protected boolean addItem(Scanner keyboard, boolean fromFile) {
		keyboard.useDelimiter("\n"); // set seperation symbol
		if (super.addItem(keyboard, fromFile)) {
			if (!fromFile) {
				while (true) {
					this.SeafoodSupplierName = Utilityhelper.helpreadString("Enter the name of the seafood supplier:",
							String.class);
					if (this.SeafoodSupplierName != null)
						break;
				}
			} else {
				this.SeafoodSupplierName = keyboard.next();
			}
		}
		return true;

	}

	protected Seafood() {
		super();
	}
	@Override
	public void outputItem(Formatter writer) throws IOException {
		super.outputItem(writer);
		writer.format("%s%n", this.SeafoodSupplierName);
	}
	
	@Override
	public String toString() {
		return super.toString() + " Seafood supplier:" + SeafoodSupplierName;
	};


}
