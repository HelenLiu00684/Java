package assignment2;

/**
 * CET - CS Academic Level 3 This class contains Assignment 1 Student Name:
 * QianJun Liu Student Number: 041150452 Course: CST8130 - Data Structures
 * 
 * @author/Professor: James Mwangi PhD.
 * 
 */

import java.util.Scanner;
/**
 * Assign2 is main menu. This class is
 * primarily used to call methods from other classes.
 */

public class Assign2 {

	static Scanner keyboard = new Scanner(System.in); // Create a Scanner object to read input

	public static void main(String[] args) {

		Assign2 assign = new Assign2(); // Create a object of class Assign1.
		Inventory invent = new Inventory(); // Create a object of class invent.
		int stringintVal = -1; // Create a variable in capture option 1-5.
		boolean resultFlag;

		while (true) { // Use true as the loop condition for continuous execution

			dispalyMean();
			System.out.print("> ");
			try {
				stringintVal = Integer.parseInt(keyboard.nextLine());
				//keyboard.nextLine();
				if (stringintVal >= 1 && stringintVal <= 8) {
					switch (stringintVal) {
					case 1 -> {
						invent.addItem(keyboard, false);

					} // Add eachItem to Inventory
					case 2 -> invent.displayInventory();// Display each Item of Inventory
					case 3 -> { // updateFlag = true success......= false failed.
						resultFlag = invent.updateQuantity(keyboard, true);// Buy some Items and increase the
																			// quantity of this item.....
						if (!resultFlag) {
							System.out.println("Error....could not buy item......");// This item is not exist.
						} else {
							System.out.println("The buying is success....");
						}
					}
					case 4 -> {
						resultFlag = invent.updateQuantity(keyboard, false);// sell some Items and decrease the
																			// quantity of this item.....
						if (!resultFlag) {
							System.out.println("Error...could not sell item...");// This item is not exist.
						} else {
							System.out.println("The selling is success....");
						}
					}
					case 5 -> {

						resultFlag = invent.searchForItem(keyboard);// search some Items

						if (!resultFlag) {
							System.out.println("Error...Code not found in inventory...");// This item is not exist.
						} else {
							System.out.println("The item has been found....");
						}
					}
					case 6 -> {
						invent.saveToFile(keyboard);// Save Inventory to File
					}
					case 7 -> {
						invent.readFromFile(keyboard);

					}
					case 8 -> { // Exit the loop after calling toExit()
						String quitBlock = """
								Exiting ...
								""";

						System.out.println(quitBlock);
						keyboard.close();
						System.exit(0);
						break;
						}
					}
				} else {
					System.out.println(" ...invalid input...try again from 1-8...\n"); // only accept the input value between 1-
																				// 5

				}
			} catch (NumberFormatException e) {// The input value can not transfer into a Integer......
				System.out.println("...invalid input...try again...\n");// This handles of NumberFormatException to
																		// print a error message.

			}
			//keyboard.close();
		}
		
	};

	/**
	 * The sub function is for invoking Object functions to display values, minimum
	 * value, maximum value, max mod min, factorialMax ......
	 *
	 * @param null.
	 * 
	 * @return null.
	 */

	public static void dispalyMean() {

		String mainMenuItemBlock = """
				Please select one of the following:
				1: Add Item to Invertory
				2: Display Current Invertory
				3: Buy Item(s)
				4: Sell Item(s)
				5: Search for Item
				6: Save Inventory to File
				7: Read Inventory from File
				8: To Exit
						""";
		System.out.print(mainMenuItemBlock + "");

	}
	
}