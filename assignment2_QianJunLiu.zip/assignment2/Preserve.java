package assignment2;
/**
 * CET - CS Academic Level 3 This class contains Assignment 1 Student Name:
 * QianJun Liu Student Number: 041150452 Course: CST8130 - Data Structures
 * 
 * @author/Professor: James Mwangi PhD.
 * 
 */
import java.io.IOException;
import java.util.Formatter;
import java.util.Scanner;



public class Preserve extends FoodItem {
	private int jarSize;

	protected boolean addItem(Scanner keyboard, boolean fromFile) {
		keyboard.useDelimiter("\n"); // set seperation symbol
		if (super.addItem(keyboard, fromFile)) {
			if (!fromFile) {
				while (true) {
					this.jarSize = Utilityhelper.helpreadInt("Enter the size of the jar in millilitres:", Integer.class);
					if (this.jarSize != -1)
						break;
				}
			} else {
				this.jarSize = Integer.parseInt(keyboard.next());
			}
		}
		return true;

	}

	protected Preserve() {
		super();
	}

	@Override
	public String toString() {
		return super.toString() + " size:" + jarSize + "mL";
	};
	@Override
	public void outputItem(Formatter writer) throws IOException {
		super.outputItem(writer);
		writer.format("%d%n", this.jarSize);
	}

}
