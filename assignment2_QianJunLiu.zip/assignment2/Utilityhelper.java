
/**
 * CET - CS Academic Level 3 This class contains Assignment 1 Student Name:
 * QianJun Liu Student Number: 041150452 Course: CST8130 - Data Structures
 * 
 * @author/Professor: James Mwangi PhD.
 * 
 */
package assignment2;

import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.Scanner;

public class Utilityhelper {

	public static int helpRecursiveBinarySearch(int intVal,ArrayList<FoodItem> arrayFoodsSorted,int indexLeft,int indexRight) {
		int flag=-1;
		int mid = indexLeft+(indexRight-indexLeft)/2;
		ArrayList<Integer> numbersSorted = new ArrayList<>();
		for(FoodItem fd:arrayFoodsSorted) {
			numbersSorted.add(fd.getItemCode());
		}
		if(indexLeft>indexRight) {
			return flag;
		}
		if(intVal==numbersSorted.get(mid)) {
			//System.out.println(numbersSorted.get(mid));
			return mid;
		}else if(intVal>numbersSorted.get(mid)) {			
			indexLeft=mid+1;
			return helpRecursiveBinarySearch(intVal,arrayFoodsSorted,indexLeft,indexRight);
		}else if(intVal<numbersSorted.get(mid)) {	
			indexRight=mid-1;
			return helpRecursiveBinarySearch(intVal,arrayFoodsSorted,indexLeft,indexRight );
		}
		return -1;
		
	}


	public static int helpreadInt(String prompt, Class type) {
		String input =null;
		System.out.print(prompt);
		input = Assign2.keyboard.nextLine();
		try {
			if (type == Integer.class) {
				int intValue = Integer.parseInt(input);
				if (intValue <= 0) { 
					System.out.println("Must be a positive integer.\n");

				}
				return intValue; 
			}
		} catch (NumberFormatException e) {
			System.out.println("Invalid input. Please enter a valid " + type.getSimpleName() + ".\n");
		}
		return -1;
	}

	public static float helpreadFloat(String prompt, Class type) {
		System.out.print(prompt);
		String input = Assign2.keyboard.nextLine();
		try {
			if (type == Float.class) {
				float floatValue = Float.parseFloat(input);
				if (floatValue <= 0) { 
					System.out.println("Must be a positive float.\n");

				}
				return floatValue; 

			}
		} catch (NumberFormatException e) {
			System.out.println("Invalid input. Please enter a valid " + type.getSimpleName() + ".\n");
		}
		return -1;
	}

	public static String helpreadString(String prompt, Class type) {
		System.out.print(prompt);
		String input = Assign2.keyboard.nextLine();
		if (type == String.class && type != null) {
			return input; 
		}
		return null;
	}

}
